configs = {
    "job_list": ["python scripts/pre_train.py +experiments/pre_train=train_prior"],
    "gpu_threshold": 1000,
    "gpu_min_num": 3,
    "gpu_max_num": 5,
}